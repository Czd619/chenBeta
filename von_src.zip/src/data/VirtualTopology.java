package data;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;
import java.util.Vector;

public class VirtualTopology {
	public static final int m=3;
	public static final int GBLow = 1;
	public static final int GBHigh = 5;
	public static final int virNodeReqComResLow = 1;
	public static final int virNodeReqComResHigh = 5;
	public static final int MAX_WEIGHT = Integer.MAX_VALUE;
	//public static final long seed = 1;
	//public static final int MAX_NODE_NUM = 14;
	
	public static final int virMaxNodeNum = 6;
	public static final int virMinNodeNum = 3;//3~8
	
	public HashMap<Integer,Vector<Integer>> ithNodePair = new HashMap<Integer, Vector<Integer>>();
	
	public int virNodeNum;
	public double[ ][ ] virTopology;
	public ArrayList<Integer> CPURequest;
	
	
	
	public VirtualTopology() {
		
		this.virNodeNum = VirNodeNumGeneration();
		//System.out.println("virNodeNum is " + this.virNodeNum);
		this.virTopology = new double[this.virNodeNum][this.virNodeNum];
		//this.virTopology = VirTopologyGeneration(this.virNodeNum);
		choosingVirTopology(this.virNodeNum);
		bandwidthRequestGeneration();
		this.CPURequest = new ArrayList<Integer>();
		this.CPURequest = CPURequestGeneration(this.virNodeNum);
	}
	
	public int getNodeNum() {
		return this.virNodeNum;
	}
	
	public int getLinkNum() {
		int linkNum = 0;
		for(int i = 0; i < this.virNodeNum; i++)
			for(int j = 0 ; j < this.virNodeNum; j++) {
				linkNum += (this.virTopology[i][j] == 0.0) ?  0 : 1;
			}
		linkNum = linkNum / 2;
		return linkNum;
	}
	
	public void choosingVirTopology(int nodeNum) {
		switch(nodeNum) {
		case 3:
			readingTopology("/Users/yuyue/Documents/workspace/VirtualMapping/three_node_VON.txt");
			break;
		case 4:
			readingTopology("/Users/yuyue/Documents/workspace/VirtualMapping/four_node_VON.txt");
			break;
		case 5:
			readingTopology("/Users/yuyue/Documents/workspace/VirtualMapping/five_node_VON.txt");
			break;
		}
	}
	
	public void readingTopology(String path) {
		try {
			FileReader fileReader = new FileReader(path);
			BufferedReader reader = new BufferedReader(fileReader);
			String line = null;
			int x = 0;
			while( (line = reader.readLine()) != null) {
				reading(line, x++);
			}
			reader.close();
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

	public void reading(String line, int x) {
		
		String[ ] temp = line.split(",");
		for(int i = 0; i < temp.length; i++) {
			this.virTopology[x][i] =Integer.parseInt(temp[i]);
		}
	}
	
	public void bandwidthRequestGeneration() {
	
		for(int i = 0; i < this.virNodeNum-1; i++) {
			for(int j = i+1; j < this.virNodeNum; j++) {
				if(this.virTopology[i][j] == 1) {
					int weight = Topology.random.nextInt(GBHigh-GBLow) + GBLow;
					this.virTopology[i][j] = this.virTopology[j][i] = weight;
				}
			}
		}
	}
	
	public double[ ][ ] VirTopologyGeneration(int nodeNum)
	{
		int totalEdges = 0;
		int addEdges = 0;
		int leftEdges = 0;
		int position = 0;
		int getEdges = 0;
	
		double[ ][ ] virWeight = new double[nodeNum][nodeNum];
		double[ ][ ] weight = new double[nodeNum][nodeNum];
		
		HashSet<Integer> selectEdges = new HashSet<Integer>();
		if(!selectEdges.isEmpty())
		{
			selectEdges.clear();
		}
					
		for (int i = 0; i < nodeNum;  i++)
		{
			for (int j = i; j < nodeNum; j++)
			{
				if (i != j)
				{
					virWeight[i][j] = virWeight[j][i] = MAX_WEIGHT;
				}
				else
				{
					virWeight[i][j] = virWeight[j][i] = 0;
				}
			}
		}
		if (m > 2)
		{
			totalEdges = m*(m-1)/2 + (this.virNodeNum - m)*m;
		}
		else if (m == 1)
		{
			totalEdges = (this.virNodeNum - m)*m;
		}
		else if (m == 2)
		{
			totalEdges = 1 + (this.virNodeNum - m)*m;
		}
		if (totalEdges < this.virNodeNum - 1)
		{
			System.out.printf("the total edges is less than this.virNodeNum,this VON failure"); 
		}
		for(int i=0;i<this.virNodeNum;i++)
		{
			for(int j = i;j<this.virNodeNum;j++)
			{
				if (j == i+1)
				{
					virWeight[i][j] = 1;
					weight[j][i] = 1;
					addEdges += 1;
				}
				if (j != i && j != i+1)
				{
					Vector<Integer> onlTwoNodes = new Vector<Integer>();
					onlTwoNodes.add(i);
					onlTwoNodes.add(j);
					ithNodePair.put(position, onlTwoNodes);
					position++;
				}
			}
		}
		leftEdges = totalEdges - addEdges;
		while (true)
		{
			int ib = leftEdges;
			Random rd = new Random();
			double fr = rd.nextDouble();
			int selectNum = (int) (ib*fr);
			selectEdges.add(selectNum);
			if (selectEdges.size() == leftEdges)
			{
				break;
			}
		}
		
		for (int i = 0; i < leftEdges; i++)
		{
			for(Iterator<Integer> it_edge = selectEdges.iterator(); it_edge.hasNext(); )
			{
				Integer size = ithNodePair.size();
				Integer index = it_edge.next();
				Vector<Integer> oneNodePair = new Vector<Integer>();
				oneNodePair = ithNodePair.get(index);
				if(oneNodePair != ithNodePair.get(size)) {
					int src = oneNodePair.elementAt(0);
					int dst = oneNodePair.elementAt(1);
					virWeight[src][dst] = virWeight[dst][src] = 1;
				}				
			}
		}
		
		getEdges = 0;
		for(int i=0; i < this.virNodeNum;i++)
		{
			for(int j=i;j<this.virNodeNum;j++)
			{
				if (i != j && virWeight[i][j] == 1)
				{
					Random rd = new Random();				
					virWeight[j][i] = virWeight[i][j] = GBLow +  rd.nextInt(GBHigh - GBLow);
					getEdges++;
				}
			}
		}
		if (getEdges != totalEdges)
		{
			System.out.printf("The generated VON failures!!");
		}	
//		for(int i = 0; i < this.virNodeNum; i++) {
//			for(int j = 0; j<this.virNodeNum; j++)
//				System.out.print(virWeight[i][j]);
//			System.out.println();
//		}
		return virWeight;
		
	}

	public int VirNodeNumGeneration() {
		
		int nodeNumber = virMinNodeNum + Topology.random.nextInt(virMaxNodeNum - virMinNodeNum);
		//System.out.println("nodeNumber is " + nodeNumber);
		return nodeNumber;
	}
	
	public ArrayList<Integer> CPURequestGeneration(int nodeNum) {
		ArrayList<Integer> request = new ArrayList<Integer>();
		//HashMap<Integer, Integer> request = new HashMap<Integer, Integer>();
		int minCPU = 5;
		int maxCPU = 10;
		for(int i = 0 ; i < nodeNum; i++) {
			request.add(Topology.random.nextInt(maxCPU - minCPU) + minCPU);
		}
		
		return request;
	}
}
