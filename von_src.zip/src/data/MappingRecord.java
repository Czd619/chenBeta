package data;

import java.util.ArrayList;
import java.util.HashMap;

public class MappingRecord {

	public int serviceID;
	public HashMap<Integer,Integer> nodeMapping;
	public HashMap<ArrayList<Integer>,ArrayList<Integer>> linkMapping;
	/*
	 * linkMapping: virLink : key.(0) virSrc, key.(1) virDst
	 * path : ������·��link��index��List
	 */
	
	public MappingRecord(int id) {
		this.serviceID = id;
		this.nodeMapping = new HashMap<Integer,Integer>();
		this.linkMapping = new HashMap<ArrayList<Integer>, ArrayList<Integer>>();
		
		
	}
	public MappingRecord() {
		// TODO Auto-generated constructor stub
	}

}
