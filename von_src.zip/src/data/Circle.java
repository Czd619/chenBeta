package data;

import java.util.*;

public class Circle {

	public int[ ][ ] newTopology ;
	public int new_size ;
	public static int MAX_WEIGHT = 999;
	public boolean[] visited;
    public ArrayList<String> paths;
    
    
    
	public Circle(int size) {
		this.new_size = size + 1;
		this.newTopology = new int[new_size][new_size];
		this.visited=new boolean[new_size];
		this.paths=new ArrayList<String>();
		this.createTopology();
		
	}
	
	public void createTopology( ) {
		int origin_size = this.new_size - 1;
		for(int i = 0; i < this.new_size; i++) {
			for(int j = 0; j< this.new_size; j++) {
				if (i!=origin_size && j!=origin_size)
					this.newTopology[i][j] = Topology.phyTopology[i][j];
				else
					this.newTopology[i][j] = MAX_WEIGHT;
			}
		}
	}
	
	public void addMirrorNode(int add_nodeID) {
		int size = this.new_size - 1;
		for(int i = 0; i < size; i++) {
			if(this.newTopology[i][add_nodeID] == 1) {
				this.newTopology[i][size] = this.newTopology[size][i] = 1;
			}
		}
	}
    
	public void getPaths(int s,int d,String path,int sum)
	{
		this.visited[s]=true;//Դ���ѷ��ʹ�. 
	 for(int i=0;i<this.new_size;i++)
	 {
		if (this.newTopology[s][i] != 1 || this.visited[i]){continue;}
		//����·��ͨ���ѷ��ʹ���������һ����㡣
		if(i==d)//�����ҵ�һ��·��
		{ 
			this.paths.add(path+"->"+d+":"+(sum+this.newTopology[s][i]));//��������
		    continue;
		}
		getPaths(i, d, path+"->"+i, sum+this.newTopology[s][i]);//������
		this.visited[i]=false;		
	 }

	}

	


	public ArrayList<Integer> path2json(String path) {
		String[] result = path.split(":");
		String[] nodes = result[0].split("->");
		ArrayList<Integer> nodesID = new ArrayList<Integer>();
		for(String node : nodes) 
			nodesID.add(Integer.parseInt(node));
		return nodesID;
			
	}
	
	public int findingNodeWithMaxCPU(int nodeNum) {
		int maxCPU = 0;
		int maxID = 0;
		for(Node node : Topology.nodes) {
			int id = node.nodeID;
			if(node.CPU > maxCPU) {
				maxCPU = node.CPU;
				maxID = id;
			}
		}
		return maxID;
	}
	public ArrayList<Integer> findingNode(int nodeNum) {
		Random random = new Random();
		ArrayList<Integer> nodeList = new ArrayList<Integer>();
		while(nodeList.size() < nodeNum) {
			int nodeID = random.nextInt(Topology.nodes.size());
			if(!nodeList.contains(nodeID))
				nodeList.add(nodeID);
		}
		return nodeList;
	}
	public void printNewTopology() {
		System.out.println("********************");
		for(int i = 0; i < this.new_size; i++) {
			for(int j = 0; j < this.new_size; j++) {
				int weight = this.newTopology[i][j];
				System.out.print(weight + " ");
			}
			System.out.println();
		}
	}
}

	
	
