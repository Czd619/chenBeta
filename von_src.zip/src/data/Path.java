package data;

import java.util.ArrayList;

public class Path {

	ArrayList<Integer> nodes;
	double latency;
	
	public Path() {
		this.nodes = new ArrayList<Integer>();
		latency = 0.0;
	}
}
