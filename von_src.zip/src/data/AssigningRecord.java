package data;

import java.util.ArrayList;
import java.util.HashMap;

public class AssigningRecord {

	public int servieID;
	public HashMap<Integer, Integer> nodeAssigning;
	public HashMap<ArrayList<Integer>, ArrayList<Integer>> linkAssigning;
	
	/*
	 * nodeAssigning: phyNode--->cpu
	 * linkAssigning: path--->[firstSlot,lastSlot]
	 */
	
	public AssigningRecord(int id) {
		this.servieID = id;
		this.nodeAssigning = new HashMap<Integer, Integer>();
		this.linkAssigning = new HashMap<ArrayList<Integer>, ArrayList<Integer>>();
	}
	
}
