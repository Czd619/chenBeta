package data;

import java.util.ArrayList;
import java.util.HashMap;

public class LinkMappingRecord {

	public int serviceID;
	
	public HashMap<ArrayList<Integer>,ArrayList<Path>> linkMapping;
	/*
	 * linkMapping: virLink : key.(0) virSrc, key.(1) virDst
	 * path : ������·��link��index��List
	 */
	
	public LinkMappingRecord(int id) {
		this.serviceID = id;
		this.linkMapping = new HashMap<ArrayList<Integer>, ArrayList<Path>>();
		
		
	}
	
}
