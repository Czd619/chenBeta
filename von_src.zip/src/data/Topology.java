package data;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Topology {

	public static final int MAX_WEIGHT = 10000;
	public static final int MAX_BANDWIDTH = 500;
	public static final int MAX_CPU = 900;

	public static int[ ][ ] phyTopology ;
	public static ArrayList<Node> nodes;
	public static ArrayList<Link> links;
	public static double utilizationOfLink;
	public static double utilizationOfNode;

	public static Random random = new Random();
	
	public static void topology(int size) {
		phyTopology = new int[size][size];
		nodes = new ArrayList<Node>();
		links = new ArrayList<Link>();
	}
	
	public static void TopologyInit(int size) {
		nodesInit(size, MAX_CPU);
		linksInit(size, MAX_BANDWIDTH);
	}
	
	public static void readingTopology(String path) {
		try {
			FileReader fileReader = new FileReader(path);
			BufferedReader reader = new BufferedReader(fileReader);
			String line = null;
			int x = 0;
			while( (line = reader.readLine()) != null) {
				reading(line, x++);
			}
			reader.close();
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}

	public  static void reading(String line, int x) {

		String[ ] temp = line.split(",");
//		System.out.println(temp.toString());
		for(int i = 0; i < temp.length; i++) {
			phyTopology[x][i] =Integer.parseInt(temp[i]);
		}
	}
	
	public static void outputTest1(int length ) {
		for(int i = 0 ; i < length; i++) {
			for(int j = 0 ; j < length; j++)
				System.out.print(phyTopology[i][j] + " ");
			System.out.println();
		}
	}
	
	public static void nodesInit(int size, int cpu) {
		
		for(int i = 0; i < size; i++) {
			Node node = new Node(i,cpu);
			int vex = 0;
			for(int id = 0; id < size; id++) {
				if(Topology.phyTopology[id][i] == 1)
					vex++;
			}
			double cost = node.CPU / MAX_CPU * vex;
			node.setCost(cost);
			nodes.add(node);
		}
	}
	
	public static void linksInit(int size, int bandwidth) {
		for(int i = 0; i < size; i++) {
			for(int j = 0; j < size; j++) {
				if(phyTopology[i][j] > 0 && phyTopology[i][j] < 999) {
					Link link = new Link(i,j,bandwidth);
					links.add(link);
				}
			}
		}
	}
	
	public static void costUpdate() {
		double sum = 0.0;
		for(Link link : Topology.links) {
			double usingSpectrum = link.spectrum.cardinality();
			double capacity = link.capacity;
			double cost = usingSpectrum/capacity;
			sum += cost;
			link.setCost(cost);
		}
		Topology.utilizationOfLink = sum / Topology.links.size();
	}
	
	public static void nodeUtilizationUpdate() {
		
	}
	
}
