package data;

public class Node {

	public int nodeID;
	public int CPU;
	public double cost;
	
	public Node(int id, int cpu) {
		this.nodeID = id;
		this.CPU = cpu;
	}
	
	public void setCost(double cost) {
		this.cost = cost;
	}
}
