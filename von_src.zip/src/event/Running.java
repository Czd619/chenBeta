package event;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import data.AssigningRecord;
import data.MappingRecord;
import data.Topology;

public class Running {

	public static final int MAX_SERVICE_NUM = 2000;
	public static int service_num = 0;
	public static int blocking = 0;
	public static final int mappingStrategy = 1;
	public static final int topologyChoose = 3;
	static private ArrayList<Service> services = new ArrayList<Service>();
	static private HashMap<Integer,MappingRecord> mapRecords = new HashMap<Integer,MappingRecord>();
	static private HashMap<Integer,AssigningRecord> assignRecords = new HashMap<Integer,AssigningRecord>();
	static private ArrayList<Integer> failedService = new ArrayList<Integer>();
	
	public static void main(String[] args) {
		
		System.out.println("--------------first we should read topology from txt file.---------------");
		/*
		 * �������˵Ķ�ȡ��Ŀǰ��six_node��NSFNet��������
		 * TopologyInit�ж��������˵�CPU��Bandwidth��Դ���г�ʼ��
		 */
		int sizeOfTopology = 0;
		switch(topologyChoose) {
		case 1:
			sizeOfTopology = 6;
			Topology.topology(sizeOfTopology);
			Topology.readingTopology("/Users/yuyue/Documents/workspace/VirtualMapping/six_node.txt");
			break;
		case 2:
			sizeOfTopology = 14;
			Topology.topology(sizeOfTopology);
			Topology.readingTopology("/Users/yuyue/Documents/workspace/VirtualMapping/NSFNet.txt");
			break;
		case 3:
			sizeOfTopology = 11;
			Topology.topology(sizeOfTopology);
			Topology.readingTopology("/Users/yuyue/Documents/workspace/VirtualMapping/Cost_239.txt");
			break;
		}

		Topology.TopologyInit(sizeOfTopology);
		Topology.outputTest1(sizeOfTopology);
		
		System.out.println("-----------------now we start to generate VON service.-----------------");
		
		/*
		 * ���ɵ���ҵ�����Ӧ����ȥҵ��service pair��
		 * ����ҵ���type=0����ȥҵ���type=1
		 * ����list�е�service���������������ݣ�arrivingTime
		 */
		for(int id = 0 ; id < MAX_SERVICE_NUM; id++) {
			Service service = new Service(id,0);
			services.add(service);
			services.add(service.generateServicePair());
		}
		Collections.sort(services, new Comparator<Service>() {
			public int compare(Service service_1, Service service_2) {
				
				double time_1 = service_1.getArrivingTime();
				double time_2 = service_2.getArrivingTime();
				return (time_1 < time_2) ? -1 : 1;
			}
		});
		printServices(MAX_SERVICE_NUM);
		
		System.out.println("---------------the next step is to mapping services.-------------");
		/*
		 * �������ӳ��
		 * type=0 Ϊ����ҵ����Ҫӳ�䲢������Դ
		 * type=1 Ϊ��ȥҵ����Ҫ���������Դ�ع��ͷ�
		 */
		for (int i = 0; i < services.size(); i++) {
			Topology.costUpdate();
			Service service = services.get(i);
			int type = service.getServiceType();
			int id = service.getServiceID();
			//printBlocking(service_num);
			switch (type) {
			case 0:
				service_num++;
		    	Mapping map = null;
				Assigning assign = new Assigning(service.getServiceID());
			    int nodeNum = service.getVirtualTopology().getNodeNum();
			    boolean node_mapping_result = false;
			    switch(mappingStrategy) {
			    case 0:
			    	map = new Mapping_random(service);
					node_mapping_result = map.nodeMapping(service.getVirtualTopology().CPURequest, nodeNum);
					break;
			    case 1:
			    	map = new Mapping_balancing(service);
					node_mapping_result = map.nodeMapping(service.getVirtualTopology().CPURequest, nodeNum);
					break;
			    case 2:
			    	map = new Mapping_tradeoff(service);
			    	node_mapping_result = map.nodeMapping(service.getVirtualTopology().CPURequest, nodeNum);
			    	break;
			    }
			    if(node_mapping_result) {
			    	map.linkMapping(service.getVirtualTopology().virTopology, nodeNum);
			    	boolean link_assigning_result = assign.assigningSpectrum(map.record.linkMapping, service.getVirtualTopology().virTopology);
			    	if(link_assigning_result) {
			    		assign.assigningCPU(map.record.nodeMapping, service.getVirtualTopology().CPURequest);
			    		service.running = true;
			    		//printRecord(map.record);
			    		mapRecords.put(id, map.record);
			    		assignRecords.put(id, assign.record);
			    		//System.out.println("id = " + id + "'s service is mapping and assigning!!!!!");
			    	}else {
			    		failedService.add(id);
			    		blocking++;
			    		System.out.println("because there is not enough bandwidth, id = " + id + "'s service can not be mapping and assigning!!!!!");
			    	}
			    		
			    }else  {
			    	failedService.add(id);
			    	blocking++;
			    	System.out.println("because there is not enough CPU, id = " + id + "'s service can not be mapping and assigning!!!!!");
		    	}				
			    

				break;
					
			case 1:
				int serviceID = service.getServiceID();
				boolean IsFailed = failedService.contains(serviceID);
				if(IsFailed)
					break;
				AssigningRecord assignRecord = assignRecords.get(id);
				for(int node : assignRecord.nodeAssigning.keySet()){
					int cpu = assignRecord.nodeAssigning.get(node);
					Topology.nodes.get(node).CPU += cpu;
				}
				for(ArrayList<Integer> path : assignRecord.linkAssigning.keySet()) {
					int firstSlot = assignRecord.linkAssigning.get(path).get(0);
					int lastSlot = assignRecord.linkAssigning.get(path).get(1);
					Assigning.SpectrumUnreservation(path, firstSlot, lastSlot);
				}
				//System.out.println("id = " + id + "'s service is leaving!!!!!!!!");
				break;
			}
			
        }
		System.out.println("blocking is " + blocking);
		
		
	}
	
	public static void printBlocking(int service_num) {
		if(service_num == 600)
    		System.out.println("blocking is " + blocking);
		if(service_num == 700)
    		System.out.println("blocking is " + blocking);
		if(service_num == 800)
    		System.out.println("blocking is " + blocking);
		if(service_num == 900)
    		System.out.println("blocking is " + blocking);
	}
	
	 
	/*
	 * �������
	 */
	public static void printMatrix(double[][] matrix, int n) {
		
		for(int i = 0 ; i < n; i++) {
			for(int j = 0; j < n; j++) {
				System.out.print(matrix[i][j]);
				System.out.print("  ");
			}
	    System.out.println();
		}
	}
	
	public static void printRecord(MappingRecord record) {
		int id = record.serviceID;
		System.out.println("this mapping record's service id is " + id);
		
		for(int virNode : record.nodeMapping.keySet()) {
			int phyNode = record.nodeMapping.get(virNode);
			System.out.println("virtual node " + virNode + " is mapping to node " + phyNode);
		}
		for(ArrayList<Integer> link : record.linkMapping.keySet()) {
			ArrayList<Integer> path = record.linkMapping.get(link);
			System.out.println("virtual link <" + link.get(0) + "," + link.get(1) + "> ---------> path" +path);
		}
	}
	
	/*
	 * path (ArrayList<Int>) ת���� links (ArrayList<Integer>)
	 * ����Integer��������topology��links��index
	 */
	public static ArrayList<Integer> Path2Link(ArrayList<Integer> path) { 
		//System.out.println("path is  " + path);
		ArrayList<Integer> links = new ArrayList<Integer>();
		for(int i = 0; i < path.size() - 1; i++) {
			int src = path.get(i);
			int dst = path.get(i+1);
			for(int index = 0; index < Topology.links.size(); index++) {
				if (Topology.links.get(index).srcID == src &&
						Topology.links.get(index).dstID == dst) {
					links.add(index);
				}
					
			}
		}
		return links;
	}
	
	/*
	 * ��֤�����
	 * ����ҵ�����ȥҵ������ɣ��Լ�������ɹ�
	 */
	public static void printServices(int serviceNum) {
		System.out.println("VON request arriving service");
		for(int i = 0 ; i < serviceNum * 2; i++) {
			if(services.get(i).getServiceType() == 1) 
				continue;
			int id = services.get(i).getServiceID();
			double time = services.get(i).getArrivingTime();
			double[ ][ ] virTopo = services.get(i).getVirtualTopology().virTopology;
			System.out.println("the service id is " + id);
			System.out.println("and this is a " + services.get(i).getServiceType() +" type service");
			System.out.println("and it's arriving time is " + time);
			printMatrix(virTopo, services.get(i).getVirtualTopology().virNodeNum);
			System.out.println(services.get(i).getVirtualTopology().CPURequest);
		}
	}
	
}
