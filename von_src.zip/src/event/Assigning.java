package event;

import java.util.ArrayList;
import java.util.HashMap;

import data.AssigningRecord;
import data.Topology;

public class Assigning {

	AssigningRecord record ;
	
	public Assigning(int id) {
		this.record = new AssigningRecord(id);
	}
	
	public void assigningCPU(HashMap<Integer, Integer> nodeMapping, ArrayList<Integer> CPURequest) {
		for(int virNode : nodeMapping.keySet()) {
			int phyNode = nodeMapping.get(virNode);
			int cpu = CPURequest.get(virNode);
			Topology.nodes.get(phyNode).CPU -= cpu;
			this.record.nodeAssigning.put(phyNode, cpu);
		}
	}
	
	public boolean assigningSpectrum(HashMap<ArrayList<Integer>, ArrayList<Integer>> linkMapping, 
			double[][] virTopology) {
		int flag = 1;
		for(ArrayList<Integer> virLink : linkMapping.keySet()) {
			int virSrc = virLink.get(0);
			int virDst = virLink.get(1);
			int bandwidth = (int)virTopology[virSrc][virDst];
			ArrayList<Integer> path = linkMapping.get(virLink);
			int result = findingFirstSlot(path, bandwidth);
			if(result >= 0) {
				ArrayList<Integer> list = new ArrayList<Integer>();
				list.add(result);
				list.add(result+bandwidth-1);
				this.record.linkAssigning.put(path, list);
				SpectrumReservation(path,result, result+bandwidth-1);
			}else {
				flag = 0;
				continue;
			}
		}
		if(flag == 0) {
			for(ArrayList<Integer> path : this.record.linkAssigning.keySet()) {
				ArrayList<Integer> list = this.record.linkAssigning.get(path);
				int firstSlot = list.get(0);
				int lastSlot = list.get(1);
				SpectrumUnreservation(path,firstSlot, lastSlot);
			}
			return false;
		}
		return true;
	}
	
	public int findingFirstSlot(ArrayList<Integer> path, int bandwidth) {
		int firstSlot = 0;
		ArrayList<Integer> links = Path2Link(path);
		int i = 0;
		while(i < links.size() && firstSlot < Topology.MAX_BANDWIDTH - bandwidth) {
			int link = links.get(i);
			int result = Topology.links.get(link).findAvailable(firstSlot, bandwidth);
			if(result >= 0) {
				firstSlot = result;
				i++;
			}else {
				firstSlot++ ;
				i = 0;
			}
		}
		if (i < links.size())
			return -1;
		return firstSlot;
	}

	public static void SpectrumUnreservation(ArrayList<Integer> path, int firstSlot, int lastSlot) {
		ArrayList<Integer> path_reverse = new ArrayList<Integer>();
		for(int i = path.size()-1; i>=0; i--) {
			path_reverse.add(path.get(i));
		}
		Unreserving(path, lastSlot, firstSlot);
		Unreserving(path_reverse, lastSlot, firstSlot);
	}
	
	public static void Unreserving(ArrayList<Integer> path, int lastSlot, int firstSlot) {
		ArrayList<Integer> links = new ArrayList<Integer>();
		links = Path2Link(path);
		for(int i : links) {
			Topology.links.get(i).Unreservation(firstSlot, lastSlot);
		}
	}
	
	public static void SpectrumReservation(ArrayList<Integer> path, 
			int firstSlot, int lastSlot) {
		ArrayList<Integer> path_reverse = new ArrayList<Integer>();
		for(int i = path.size()-1; i>=0; i--) {
			path_reverse.add(path.get(i));
		}
		Reserving(path, lastSlot, firstSlot);
		Reserving(path_reverse, lastSlot, firstSlot);
	}
	
	
	public static void Reserving(ArrayList<Integer> path, int lastSlot, int firstSlot) {
		ArrayList<Integer> links = new ArrayList<Integer>();
		links = Path2Link(path);
		for(int i : links) {
			Topology.links.get(i).Reservation(firstSlot, lastSlot);
		}

	}
	/*
	 * path (ArrayList<Int>) ת���� links (ArrayList<Integer>)
	 * ����Integer��������topology��links��index
	 */
	public static ArrayList<Integer> Path2Link(ArrayList<Integer> path) { 
		//System.out.println("path is  " + path);
		ArrayList<Integer> links = new ArrayList<Integer>();
		for(int i = 0; i < path.size() - 1; i++) {
			int src = path.get(i);
			int dst = path.get(i+1);
			for(int index = 0; index < Topology.links.size(); index++) {
				if (Topology.links.get(index).srcID == src &&
						Topology.links.get(index).dstID == dst) {
					links.add(index);
					//System.out.println("this time is successful!!");
				}
					
			}
		}
		return links;
	}
}
