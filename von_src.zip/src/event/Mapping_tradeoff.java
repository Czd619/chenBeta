package event;

import java.util.ArrayList;
import java.util.Random;

import data.Circle;
import data.Node;
import data.Topology;

public class Mapping_tradeoff extends Mapping{

	//public Circle circle;
	
	public Mapping_tradeoff(Service service) {
		super(service);
		
		
	}
	
	@Override
	public boolean nodeMapping(ArrayList<Integer> cpuRequest, int nodeNum) {
		boolean success = false;
		ArrayList<Integer> nodeList = new ArrayList<Integer>();
		nodeList = findingNodes(nodeNum);
		//System.out.println("nodelist is " + nodeList);

		if(nodeList != null)
			success = IsNodeAvailable(cpuRequest, nodeList);
		if(success) {
			//Random random = new Random();
			for(int i = 0; i < nodeNum; i++) {
				int nodeID = nodeList.get(i);
				this.record.nodeMapping.put(i, nodeID);
			}
		}
		//System.out.println("service is " + success);
		return success;
	}
	
	
	@Override
	public ArrayList<Integer> findingNodes(int nodeNum) {
		int minLength = 8;
		int dst = Topology.nodes.size();
		String path = null;
		Circle circle = new Circle(Topology.nodes.size());
		int src = circle.findingNodeWithMaxCPU(nodeNum);
		circle.addMirrorNode(src);
		circle.getPaths(src, dst, ""+src, 0);
		
		for(String e: circle.paths) {
			String[] result = e.split(":");
			int length = Integer.parseInt(result[1]);
			
			if(length >= nodeNum && length <= minLength) {
				minLength = length;
				path = e;
			}
	    }
		
		/*
		for(Node node : Topology.nodes){
			Circle circle = new Circle(Topology.nodes.size());
			int src = node.nodeID;
			circle.addMirrorNode(src);
			//circle.printNewTopology();
			circle.getPaths(src, dst, ""+src, 0);
			
			for(String e: circle.paths) {
				String[] result = e.split(":");
				int length = Integer.parseInt(result[1]);
				//if(length >= nodeNum && length <= minLength) 
				if(length == nodeNum) {
					minLength = length;
					path = e;
				}
		    }
		}
		*/
		return path2json(path);
		
	}
	
	public ArrayList<Integer> path2json(String path) {
		String[] result = path.split(":");
		String[] nodes = result[0].split("->");
		ArrayList<Integer> nodesID = new ArrayList<Integer>();
		for(String node : nodes) 
			nodesID.add(Integer.parseInt(node));
		return nodesID;
			
	}
	
}
