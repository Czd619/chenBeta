package event;

import java.util.ArrayList;
import java.util.Collections;

import data.MappingRecord;
import data.Topology;

public class Mapping {

	static final int MAX_WEIGHT = 10000;
	public MappingRecord record;
	
	public Mapping(Service  service) {
	    int id = service.getServiceID();
	    this.record = new MappingRecord(id);
	}
	
	
	public boolean IsNodeAvailable(ArrayList<Integer> cpuRequest, ArrayList<Integer> nodeList) {
		int nodeNum = cpuRequest.size();
		int result = 0;
		for(int i = 0 ; i < nodeNum; i++) {
			int cpu = cpuRequest.get(i);
			int index = nodeList.get(i);
			if(Topology.nodes.get(index).CPU > cpu) {
				result++;
			}
		}
		if(result == nodeNum)
			return true;
		else
			return false;
	}
	
	public void linkMapping(double[ ][ ] virTopology, int size) {
		
	}
	public boolean nodeMapping(ArrayList<Integer> cpuRequest, int nodeNum) {
		// TODO Auto-generated method stub
		return false;
	}

	public ArrayList<Integer> findingNodes(int nodeNum) {
		// TODO Auto-generated method stub
		return null;
	}
	

	/*
	 * D�㷨����src��dst֮������·��
	 */
	public ArrayList<Integer> ComputeShortestPath(int src, int dst)
    {
		int size = Topology.phyTopology.length;
    	int[] Distance = new int[size];
        int[] former = new int[size];
        boolean[] end = new boolean[size];
        ArrayList<Integer> pathList = new ArrayList<Integer>();
        
    	for(int i=0;i<size;++i) {
    		end[i]=false;
            Distance[i]=Topology.phyTopology[src][i];
            if(Distance[i]<MAX_WEIGHT && Distance[i]!=0)
    		{
    			former[i]= src;
    		}
            else   former[i]=MAX_WEIGHT;
    	}
        end[src] = true;
        former[src] = src;
        for(int i=1;i<size;++i)  {
    		int w;
            int min=MAX_WEIGHT;
            int v=-1;
            for(w=0;w<size;++w)
    		{
    			if(!end[w] && Distance[w]<min)
    			{
    				v=w;
                    min=Distance[w];
    			}
    		}
            if(v!=-1)
    		{
    			end[v]=true;
                for(w=0;w<size;++w)
    			{
    				if(!end[w]&&(min+Topology.phyTopology[v][w]<Distance[w]) && Topology.phyTopology[v][w]<MAX_WEIGHT)
    				{
    					Distance[w]=min+Topology.phyTopology[v][w];
                        former[w]= v;
    				}
    			}
    		}
    	}
    	pathList.add(dst);
    	int i = 1;
    	while(src != dst) {
            if(i == former[dst]) {
    			dst = i;
    			pathList.add(dst);
    		}
    		i = (i < size ? i+1 : i-size);
    	}	   
    	Collections.reverse(pathList);      
        return pathList;
    }
	
	
}
