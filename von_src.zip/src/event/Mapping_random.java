package event;

import data.Link;
import data.MappingRecord;
import data.Node;
import data.Topology;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

import javax.swing.text.html.HTMLDocument.Iterator;

public class Mapping_random extends Mapping {

	public Mapping_random(Service service) {
		super(service);
		// TODO Auto-generated constructor stub
	}

	/*
	 * ���ѡȡ����topology�еĽڵ���ӳ��cpuRequest�еĽڵ�
	 * constraint��node.CPU > request.CPU
	 * ���ӳ���������Ϊ3�Σ�������������δ����constraint������Ϊӳ��ʧ��
	 */
	@Override
	public boolean nodeMapping(ArrayList<Integer> cpuRequest, int nodeNum) {
		boolean success = false;
		int times = 0;
		ArrayList<Integer> nodeList = new ArrayList<Integer>();
		while(!success && times < 1) {
			nodeList = findingNodes(nodeNum);
			success = IsNodeAvailable(cpuRequest,nodeList);
			times++;
		}
		if(success) {
			for(int i = 0; i < nodeNum; i++) {
				int nodeID = nodeList.get(i);
				this.record.nodeMapping.put(i, nodeID);
			}
		}
		return success;
	}
	
	@Override
	public ArrayList<Integer> findingNodes(int nodeNum) {
		
		ArrayList<Integer> nodeList = new ArrayList<Integer>();
		while(nodeList.size() < nodeNum) {
			int nodeID = Topology.random.nextInt(Topology.nodes.size());
			if(!nodeList.contains(nodeID))
				nodeList.add(nodeID);
		}
		return nodeList;
	}
	
	@Override
	public void linkMapping(double[ ][ ] virTopology, int size) {
		for(int i = 0 ; i < size-1; i++) 
			for(int j = i+1; j < size; j++) {
				double bandwidth = virTopology[i][j];
				if(bandwidth > 0 && bandwidth < 999) {
					ArrayList<Integer> virLink = new ArrayList<Integer>();
					virLink.add(i);
					virLink.add(j);
					int src = this.record.nodeMapping.get(i);
					int dst = this.record.nodeMapping.get(j);
					ArrayList<Integer> path = new ArrayList<Integer>();
					path = ComputeShortestPath(src, dst);
					this.record.linkMapping.put(virLink, path);

				}
			}
	}
	
	
}
