package event;

import java.util.ArrayList;

import data.Link;
import data.Node;
import data.Topology;

public class Mapping_balancing extends Mapping{

	public boolean[] visited;
	public int virTopoSize;
	public ArrayList<String> paths;
	
	public Mapping_balancing(Service service) {
		super(service);
		this.virTopoSize = service.getVirtualTopology().virNodeNum;
		this.visited = new boolean[Topology.nodes.size()];
		this.paths = new ArrayList<String>();
		// TODO Auto-generated constructor stub
	}

	/*
	 * ���ø��ؾ�����ԵĽڵ�ӳ���㷨
	 * ��Topology.nodes����cpu��Դ���н�������
	 * �����ṩʣ����Դ��Ľڵ�
	 */
	@Override
	public boolean nodeMapping(ArrayList<Integer> cpuRequest, int nodeNum) {
		boolean success = false;
		ArrayList<Integer> nodeList = findingNodes(nodeNum);
		ArrayList<Integer> cpuRequest_sorting = new ArrayList<Integer>();
		for(int i = 0; i < nodeNum; i++) {
			int cpu_max = 0;
			int id_max = 0;
			for(int j = 0; j < nodeNum; j++) {
				if(cpuRequest.get(j)>cpu_max && !cpuRequest_sorting.contains(j)) {
					cpu_max = cpuRequest.get(j);
					id_max = j;
				}
			}
			cpuRequest_sorting.add(id_max);
		}
		success = IsNodeAvailable(cpuRequest_sorting, nodeList);
		if(success) {
			int index = 0;
			for(int virNodeID : cpuRequest_sorting) {
				int nodeID = nodeList.get(index);
				this.record.nodeMapping.put(virNodeID, nodeID);
				index++;
			}
		}
		return success;
	}
	
	@Override
	public ArrayList<Integer> findingNodes(int nodeNum) {
		ArrayList<Integer> nodeList = new ArrayList<Integer>();

		while(nodeList.size() < nodeNum) {
			int maxCPU = 0;
			int maxID = 0;
			for(Node node : Topology.nodes) {
				int id = node.nodeID;
				if(node.CPU > maxCPU && !nodeList.contains(id)) {
					maxCPU = node.CPU;
					maxID = id;
				}
			}
			nodeList.add(maxID);	
		}
		return nodeList;
	}
	
	@Override
	public void linkMapping(double[ ][ ] virTopology, int size) {
		for(int i = 0 ; i < size-1; i++) 
			for(int j = i+1; j < size; j++) {
				double bandwidth = virTopology[i][j];
				if(bandwidth > 0 && bandwidth < 999) {
					ArrayList<Integer> virLink = new ArrayList<Integer>();
					virLink.add(i);
					virLink.add(j);
					int src = this.record.nodeMapping.get(i);
					int dst = this.record.nodeMapping.get(j);
					getPaths(src, dst, ""+src, 0);
					
					ArrayList<Integer> path = getBalancingPath();
					this.record.linkMapping.put(virLink, path);
					
					this.visited = new boolean[Topology.nodes.size()];
					this.paths.clear();
				}
			}
	}
	
	public void getPaths(int s,int d,String path,int sum)
	{
		
		this.visited[s]=true;//Դ���ѷ��ʹ�. 
		for(int i=0;i<Topology.nodes.size();i++) {
			if (Topology.phyTopology[s][i] != 1 || this.visited[i]){continue;}
		     //����·��ͨ���ѷ��ʹ���������һ����㡣
			if(i==d) { 
				sum += Topology.phyTopology[s][i];
			//	if(sum > (Topology.nodes.size() - 3))
				//	break;
				this.paths.add(path+"->"+d+":"+(sum+Topology.phyTopology[s][i]));//��������
				continue;
			}
		    getPaths(i, d, path+"->"+i, sum+Topology.phyTopology[s][i]);//������
		    this.visited[i]=false;		
	    }

	}
	
	public ArrayList<Integer> String2Int(String path) {
		String[] result = path.split(":");
		String[] nodes = result[0].split("->");
		ArrayList<Integer> nodesID = new ArrayList<Integer>();
		for(String node : nodes) 
			nodesID.add(Integer.parseInt(node));
		return nodesID;
			
	}

	public ArrayList<Integer> getBalancingPath() {
		ArrayList<Integer> workpath = new ArrayList<Integer>();
		double minCost = 1.0;
		//System.out.println("there is " + this.paths.size() + " path !!");
		for(String eachPath : this.paths) {
			//System.out.println(eachPath);
			ArrayList<Integer> path = String2Int(eachPath);
			double sum = 0.0;
			for(int i = 0; i < path.size()-1; i++) {
				int src = path.get(i);
				int dst = path.get(i+1);
				Link link = findingLink(src, dst);
				sum += link.cost;
			}
			double linkNum = path.size() - 1;
			double cost = sum / linkNum;
			if(cost <= minCost) {
				minCost = cost;
				workpath.clear();
				for(Integer node : path) {
					workpath.add(node);
				}
			}
			path.clear();
		}
		if(workpath.isEmpty())
			System.out.println("can't find any path!!!");
		return workpath;
	}
	
	public Link findingLink(int src, int dst) {
		
		for(Link link : Topology.links) {
			if(link.srcID == src && link.dstID == dst)
				return link;
		}
		return null;
	}

	
}
