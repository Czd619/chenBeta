package KSP;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Iterator;

import event.Service;


public class Graph {

	public static final int INFINITE = 999;
	public static final int NUM_SLOT = 100;
	public static final int MaxNodeNum = 14;
	public int[][] weight; 
	public int[][] updateWeight;
	public int m_initSize; // original size of "m_adj_map", it's fixed.
	public int m_size; // size of "m_adj_map", because the "m_adj_map" maybe be reallocated. 
	public LinkedList<Vertex> m_adj_map; // 
	public LinkedList<Vertex> m_init_adj_map;
	public LinkedList<Vertex> m_in_map;
	public LinkedList<Vertex> m_init_in_map;
		
	public Graph() {
		this.m_initSize = 0;
		this.m_size = 0;
		this.weight = new int[MaxNodeNum][MaxNodeNum];
		this.updateWeight = new int[MaxNodeNum][MaxNodeNum];
		this.m_adj_map = new LinkedList<Vertex>(); // 
		this.m_init_adj_map= new LinkedList<Vertex>();
		this.m_in_map = new LinkedList<Vertex>();
		this.m_init_in_map = new LinkedList<Vertex>();
	}
	
	public Graph(LinkedList<Vertex> adjMap) {
		this.m_initSize = adjMap.size();
		this.m_size = adjMap.size();
		this.m_adj_map = adjMap;
		this.weight = new int[MaxNodeNum][MaxNodeNum];
		this.updateWeight = new int[MaxNodeNum][MaxNodeNum];
	}

	public void reading(String line, int x) {

		String[ ] temp = line.split(",");
		for(int i = 0; i < temp.length; i++) {
			this.weight[x][i] = this.updateWeight[x][i] =Integer.parseInt(temp[i]);
		}
	}
	
	public void readTopology(int size, String name)
	{

		try {
			FileReader fileReader = new FileReader(name);
			BufferedReader reader = new BufferedReader(fileReader);
			String line = null;
			int x = 0;
			while( (line = reader.readLine()) != null) {
				reading(line, x++);
			}
			
			reader.close();
		} catch(FileNotFoundException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}

	}
	public void createLinkTab()
	{
		int size;
		this.m_size = this.m_initSize = size = MaxNodeNum;
		System.out.println(size + " ");
		for(int i = 0; i < size; i++) {
			Vertex ver = new Vertex(i,0);
			this.m_adj_map.addLast(ver);
			this.m_in_map.addLast(ver);
		}
		for(int i=0;i<size;i++)
		{
			for(int j=0;j<size;j++)
			{
				double weightValue;
				weightValue = updateWeight[i][j];
				if (weightValue > 0 && weightValue < INFINITE - 1 )
				{
					Vertex v1 = new Vertex(j, weightValue);
					Vertex v2 = new Vertex(i, weightValue);
					v1.m_next = this.m_adj_map.get(i).m_next;
					this.m_adj_map.get(i).m_next = v1;
					v2.m_next = this.m_in_map.get(j).m_next;
					this.m_in_map.get(j).m_next = v2;
					
				}				
			}	
		}
		this.m_init_in_map = this.m_in_map;
		this.m_init_adj_map = this.m_adj_map;
		
	}

	public void delete_adj_list(LinkedList<Vertex> map)
	{
		for (int i=0;i<map.size();i++)
		{
			Vertex v = map.get(i).m_next;
			Vertex p = null;
			while(v!=null) {
				p = v;
				v = v.m_next;
				p = null;
			}
			
		}
	}
		
	public void dijkstra(int srcId, LinkedList<Double> dist, LinkedList<Integer> path)
	{
		
		for(int i=0;i<this.m_size;i++)
		{
			dist.add((double)INFINITE);
			path.add(-1);
		}
		dist.set(srcId, 0.0);
		
		boolean[] done = new boolean[this.m_size];
		for (int i=0;i<this.m_size;i++)
		{
			done[i] = false;
		}

		PriorityQueue<Edge> pq = new PriorityQueue<Edge>();	
		
		Edge edge = new Edge(srcId, 0);
		pq.add(edge);
		while(!pq.isEmpty()) {
			Edge out = pq.poll();

			if(done[out.m_id]==true)
			{
				continue;
			}
			done[out.m_id] = true;
			dist.set(out.m_id, out.m_metric);
			
			for(Vertex vertex=m_adj_map.get(out.m_id).m_next;vertex!=null;vertex=vertex.m_next)
			{
				if(done[vertex.m_id]==false)
				{
					if(vertex.m_weightValue + out.m_metric < dist.get(vertex.m_id))
					{
						dist.set(vertex.m_id, vertex.m_weightValue + out.m_metric);
						path.set(vertex.m_id, out.m_id);
						Edge in = new Edge(vertex.m_id, dist.get(vertex.m_id));
						pq.add(in);
						
					}
				}
			}
		}
	}
	
	public double dijkstra( int start , int end , LinkedList<Integer> path_list )
	{
		LinkedList<Integer> paths = new LinkedList<Integer>();
		LinkedList<Double> dist = new LinkedList<Double>();
		dijkstra(start, dist, paths);
		
	    if(dist.get(end) > INFINITE -1) { 
			return -1;
		}
		// parse the shortest path
		int i = end;	
		while(i>=0)
		{		
			path_list.addFirst(i);
			i=paths.get(i);			
		}
		double min = dist.get(end);
		return min;
	}	
	
	public int ksp( int src, int dest, int k , LinkedList<LinkedList<Integer>> kpaths )
	{	
		/* Initialize */	
		LinkedList<Integer> Path = new LinkedList<Integer>();
		LinkedList<Integer> Prime = new LinkedList<Integer>();
		LinkedList<Integer> Base = new LinkedList<Integer>();
		LinkedList<Double> Dist = new LinkedList<Double>();
		
		for(int i=0;i<this.m_size;i++)
		{ 
			Prime.add(-1);
			Base.add(i);
		}
		
		/* Find the shortest path firstly */	
		dijkstra(src, Dist, Path); 
		if( Dist.get(dest) > INFINITE -1 ) 
			return 0;
		LinkedList<Integer> path = new LinkedList<Integer>(); 
		int j = Path.get(dest);	
		path.addLast(dest);
		while(j >= 0)
		{		
			path.addFirst(j);
			j=Path.get(j);			
		}
		kpaths.addLast(path); // store the shortest path

		/* Find the 2th - kth shortest paths */
		int ki = 1,kj = 1;
		while(ki < k && kj < 50)
		{
			/* Find the first node with more than a single incoming arc */
			int nh = -1;
			while( path.size()>0 )
			{
				int node = path.pollFirst();
				int count = 0;
				Vertex vertex = this.m_in_map.get(node); 
				while(vertex.m_next!=null)
				{
					count++;
					vertex = vertex.m_next;
					if( count > 1 ) 
						break;
				}			
				if( count > 1 ) 
				{ 
					nh = node; 
					break; 
				}
			}

			if( nh == -1 ) break; // there is NOT an alternative path, exit!

			int ni = -1;
			/* Add the first prime node to graph */
			if( Prime.get(nh) < 0 )
			{
				int nh1 = addNode(nh,Path.get(nh));

				/* compute the minimal distance from node 0 to nh1 */
				double min_dist = INFINITE;
				int min_node = -1;
				for(Vertex ver = this.m_in_map.get(nh1).m_next; ver != null ; ver = ver.m_next)
				{
					//cout << Dist[i] << " " << m_adj_map[i][nh1] << endl; // for debug
					int id = ver.m_id;
					double wei = ver.m_weightValue;
					if( Dist.get(id) + wei < min_dist )
					{
						min_dist = Dist.get(id) + wei;
						min_node = id;
					}
				}			
				Dist.addLast(min_dist);
				Path.addLast(min_node);
				Prime.addLast(-1);
				Prime.set(nh, nh1);

				/* record the base node */
				int basei = nh;
				while(basei != Base.get(basei))
					basei = Base.get(basei);
				Base.addLast(basei);

				if(path.size()>0)
					ni = path.pollFirst();
					
			}
			/*  Get node ni, it must meet it's the first node following nh in path, but its prime node ni` is NOT in graph */
			else
			{
				while( path.size()>0 )
				{
					ni = path.pollFirst();
					if(Prime.get(ni) < 0) 
						break;				
				}
			}		

			/* Add the other prime nodes to graph */
			while(true)
			{
				int ni1 = addNode(ni,Path.get(ni));
				int temp1 = Path.get(ni);
				int temp2 = Prime.get(temp1);
				if( temp2 >= 0 )	
				{
					double wei = Dist.get(ni) - Dist.get(temp1);
					Vertex ver1 = new Vertex(ni1, wei);
					Vertex ver2 = new Vertex(temp2, wei);
					ver1.m_next = m_adj_map.get(temp2).m_next;
					m_adj_map.get(temp2).m_next = ver1;
					ver2.m_next = m_in_map.get(ni1).m_next;
					m_in_map.get(ni1).m_next = ver2;
				}
				/* compute the minimal distance from node 0 to ni1 */
				double min_dist = INFINITE;
				int min_node = -1;
				
				for(Vertex ver = m_in_map.get(ni1).m_next; ver != null ; ver = ver.m_next)
				{
					//cout << Dist[i] << " " << m_adj_map[i][nh1] << endl; // for debug
					int id = ver.m_id;
					double wei = ver.m_weightValue;
					if( Dist.get(id) + wei < min_dist )
					{
						min_dist = Dist.get(id) + wei;
						min_node = id;
					}
				}
				Dist.addLast(min_dist);
				Path.addLast(min_node);
				Prime.addLast(-1);
				Prime.set(ni, ni1);

				/* record the base node */
				int basei = ni;
				while(basei != Base.get(basei))
					basei = Base.get(basei);
				Base.addLast(basei);

				if( path.size()==0 ) 
					break;
				ni = path.pollFirst();
							
			}

			/* get the kth shortest path */			
			if( ni==-1 ) ni = nh; // if nh is just the end node.
			LinkedList<Integer> temp = new LinkedList<Integer>();		
			j = Prime.get(ni);
			while(j>=0)
			{
				path.addFirst(j);
				temp.addFirst(Base.get(j));
				j = Path.get(j);
			}
			if(temp.size()<2) 
				break; 
			Iterator<Integer> it1  = temp.iterator();
			Iterator<Integer> it2 = temp.iterator();
			boolean reg = true;
			do {
				it2.hasNext();
				do {
					if (it1.next() == it2.next())
					{
						reg = false;
						break;
					}
				}while(it2.hasNext());
				if (!reg)
				{
					break;
				}
			}while (it1.hasNext());
			if (reg)
			{
				kpaths.addLast(temp);  // store the kth shortest path
				ki++;
			}
			kj++;
			//this->Output(); // for debug
		}
		return ki;
	}
	
	public int addNode(int ni,int preni)
	{
		Vertex vertex = new Vertex(m_size, 0);
		this.m_adj_map.addLast(vertex);
		this.m_in_map.addLast(vertex);
		for(Vertex ver = this.m_in_map.get(ni).m_next; ver!= null; ver = ver.m_next) {
			int id = ver.m_id;
			double wei = ver.m_weightValue;
			if(id != preni) {
				Vertex v2 = new Vertex(this.m_size, wei);
				v2.m_next = this.m_adj_map.get(id).m_next;
				this.m_adj_map.get(id).m_next = v2;
				
				Vertex v3 = new Vertex(id, wei);
				v3.m_next = this.m_in_map.get(this.m_size).m_next;
				this.m_in_map.get(m_size).m_next = v3;
			}
		}
		return m_size++;
	}
}
