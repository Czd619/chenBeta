package KSP;

public class priority_queue {

}
