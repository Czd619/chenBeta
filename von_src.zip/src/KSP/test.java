package KSP;

import java.util.LinkedList;

public class test {

	public static String path = "/Users/yuyue/Documents/workspace/VirtualMapping/NSFNet.txt";
	public static void main(String[] args) {
		
		Graph graph = new Graph();
		graph.readTopology(14, path);
		graph.createLinkTab();
		int src = 0;
		int dest = 5;
		int k = 2;
		LinkedList<LinkedList<Integer>> kpaths = new LinkedList<LinkedList<Integer>>();
		graph.ksp(src, dest, k, kpaths);
		for(LinkedList<Integer> path : kpaths) {
			System.out.println(path.toString());
		}
		
	}
}
