package KSP;

public class Edge implements Comparable<Edge>{

	public int m_id;
	public double m_metric;
	
	public Edge() {
		
	}
	public Edge(int id, double w) {
		this.m_id = id;
		this.m_metric = w;
	}
	
	@Override
	public int compareTo(Edge o) {
		// TODO Auto-generated method stub
		if(this.m_metric>o.m_metric)
			return 1;
		else if(this.m_metric < o.m_metric)
			return -1;
		return 0;
	}
}
