package KSP;

public class Vertex {

	public int m_id;
	public Vertex m_next;
	double m_weightValue;
	
	public Vertex()
	{
		this.m_next = null;
	}
	public Vertex(int id, double w)
	{
		this.m_next = null;
		this.m_id = id;
		this.m_weightValue = w;
	}

	public Vertex(Vertex ver) {
		this.m_id = ver.m_id;
		this.m_next = ver.m_next;
		this.m_weightValue = ver.m_weightValue;
	}
	
	public Vertex and_operator (Vertex _graph) {
		this.m_id = _graph.m_id;
		this.m_weightValue = _graph.m_weightValue;
		if(_graph.m_next != null) {
			this.m_next = new Vertex();
			this.m_next = _graph.m_next;
		}else {
			this.m_next = null;
		}
		return this;
	}
	
}
